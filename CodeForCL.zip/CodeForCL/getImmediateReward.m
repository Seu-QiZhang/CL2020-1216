%This file is created by Xu Xiaoli on 24/09/2020

%It evaluate the expected immediate reward under certain belief vector

function reward=getImmediateReward(belief,beta,action)
%we don't have to evaluate the common part
if (action==1)||(action==0)
    reward=-beta;
else
    r_vec=belief(1,:);
    w_vec=belief(2,:);
    prob=belief(4,:);
    reward=-beta*(prob*(r_vec+w_vec)');
end





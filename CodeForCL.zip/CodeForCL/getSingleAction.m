%This file is created by Xu Xiaoli on 26/04/2020
%It simulate the performance of single-action policy with approximated
%value function

%Thsi file is modified by Xu Xiaoli on 24/09/2020
%It consider a more general decesion policy which includes the scenario
%where no information is delievered for saving the channel resource

%beta: the weight coefficient to balance the channel utilization and
%latency. When beta=0, we aims to minimize the latency. When beta=1, we aims to minimize the channel utilization 
function [ExpectedDelay, ChannelUtilization]=getSingleAction(lambda,p,N,T,beta)

PacketArrive=[1, (rand(1,N-1)<lambda)]; %Start from the first arriving packet
GenerateTime=find(PacketArrive==1);
DeliverTime=zeros(1,length(GenerateTime));%to store the deliver time for all the packets

Action=zeros(1,N); %To record the actions taken during all the N time slots
RealState=zeros(3,N); %To record the real value of waiting packet at the reciever side
w=0;
d=0;

%====At the beginning of the first time slot, always send information packet==========
State=[1,0,0]';
belief=[State; 1];
Action(1)=0; % send the first information packet
numPacket=1; %the processed packet increased by 1
if rand>p
   DeliverTime(1)=2;% it is completely received at the beginning of the second time slot
else
   w=1;
end
TransQueue=0;

for i=2:N
    %There is no feedback information yet
    TransQueue=TransQueue+PacketArrive(i);
    RealState(:,i)=[TransQueue;w;d];
    if i<T+1
        %no feedback information yet
        belief=UpdateBelief2(belief,PacketArrive(i),Action(i-1),p,1); % the belief state at the beginning of the second time slot
    else
        belief=UpdateBelief2([RealState(:,i-T);1],PacketArrive(i-T+1:i),Action(i-T:i-1),p,T);
    end
    belief1_arrive0=UpdateBelief2(belief,0,1,p,1); %If take action 1 and no packet arrive in the next time slot
    %belief1_arrive1=UpdateBelief2(belief,1,1,p,1); %If take action 1 and new packet arrive in the next time slot
    belief1_arrive1=belief1_arrive0+[1;0;0;0]*ones(1,size(belief1_arrive0,2));
    if TransQueue==0
        %In this case, we may consider remain silent or send an coded
        %packet
        beliefm1_arrive0=UpdateBelief2(belief,0,1,p,1); %If take action -1 and no packet arrive in the next time slot
        beliefm1_arrive1=UpdateBelief2(belief,1,1,p,1); %If take action -1 and new packet arrive in the next time slot
        valuem1=getImmediateReward(belief,beta,-1)+(1-lambda)*getValueofState(beliefm1_arrive0,p,lambda,beta)+lambda*getValueofState(beliefm1_arrive1,p,lambda,beta);
        value1=getImmediateReward(belief,beta,1)+(1-lambda)*getValueofState(belief1_arrive0,p,lambda,beta)+lambda*getValueofState(belief1_arrive1,p,lambda,beta);
        if value1>=valuem1
            %Make the decision to send a coded packet
            Action(i)=1;
            if rand>p
                d=d+1;
                if d>=w-0.001
                    DeliverTime((numPacket-w+1):numPacket)=i+1;%all the waiting packets are delivered
                    w=0;
                    d=0;
                end
            end
        else
            Action(i)=-1;
        end
    else
        %We need to make decision which action to take
        belief0_arrive0=UpdateBelief2(belief,0,0,p,1);%if no packet come at next slot and take action 0
        belief0_arrive1=UpdateBelief2(belief,1,0,p,1);%if take action 0 and there willl be a packet arrival at the beginning of next time slot
        value0=(1-lambda)*getValueofState(belief0_arrive0,p,lambda,beta)+lambda*getValueofState(belief0_arrive1,p,lambda,beta);
        value1=(1-lambda)*getValueofState(belief1_arrive0,p,lambda,beta)+lambda*getValueofState(belief1_arrive1,p,lambda,beta);
        if value0>=value1
            %send information packet
            Action(i)=0; %send an information packet
            numPacket=numPacket+1; %the processed packet increased by 1
            TransQueue=TransQueue-1; %transmitting queue decrease by 1
            w=w+1;
            if rand>p
                %if this packet is successfully received
               if w==1
                   %This is the only waiting packet
                   DeliverTime(numPacket)=i+1; %received at the beginning of the next time slot
                   w=0;
               else
                   d=d+1;
               end
            end
        else
            Action(i)=1;
            if rand>p
                d=d+1;
                if d>=w-0.001
                    DeliverTime((numPacket-w+1):numPacket)=i+1;%all the waiting packets are delivered
                    w=0;
                    d=0;
                end
            end
        end
    end
end

TotalDelivered=sum(DeliverTime>=1);% only count those packets that has been delivered

ExpectedDelay=mean(DeliverTime(1:TotalDelivered)-GenerateTime(1:TotalDelivered));
%DeliverRatio=TotalDelivered/length(GenerateTime);
ChannelUtilization=1-sum(Action==-1)/length(Action);

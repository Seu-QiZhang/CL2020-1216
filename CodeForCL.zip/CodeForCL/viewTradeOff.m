%This file is created by Xu Xiaoli on 24/09/2020
%It view the trade-off between end-to-end latency and channel utilization
%that achieved with sigle action policy. 

clear;
close all;
clc;
lambda=0.7;
p=0.2;
T=8;

U_min=lambda/(1-p);
D_min=(1-lambda)/(1-p-lambda); %ARQ

U_vec=[U_min:0.01:1,1];
D_blind=((U_vec-lambda)*(1-p)-lambda*p+p)./((U_vec-lambda)*(1-p)-lambda*p)+lambda*p./((U_vec-lambda)*(1-p)-lambda*p).^2;

%===========Find tradeoff achieved with Threshold coding===============
thres_vec=[0.5,1,1.5,2];
TH_U_vec=zeros(1,length(thres_vec));
TH_D_vec=zeros(1,length(thres_vec));
iter=10;
for j=1:length(thres_vec)
    thres=thres_vec(j);
    TU=zeros(1,iter);
    TD=zeros(1,iter);
    for n=1:iter
        [TD(n), TU(n)]=getThresholdCoding(lambda,p,50000,T,thres);
    end
    TH_D_vec(j)=mean(TD)
    TH_U_vec(j)=mean(TU)
end


%========Find the trad-off achieved with POMDP======

beta_vec=[0,  0.01,1];
SA_U_vec=zeros(1,length(beta_vec));
SA_D_vec=zeros(1,length(beta_vec));
for i=1:length(beta_vec)
    beta=beta_vec(i);
    [SA_D_vec(i), SA_U_vec(i)]=getSingleAction(lambda,p,50000,T,beta)
end

D_max=35; %set a limit for the plot
figure;
plot(U_vec,D_blind,'k-','LineWidth',1.5);
hold on;
plot(U_min,D_min, 'ro','MarkerFaceColor','r');
plot(SA_U_vec,SA_D_vec,'ms-','MarkerFaceColor','m','LineWidth',1.5);
plot(TH_U_vec,TH_D_vec,'bs-','MarkerFaceColor','b','LineWidth',1.5);
plot([U_min,U_min],[D_min,D_max],'r--','LineWidth',1.5);
plot([U_min,1],[D_min,D_min],'r--','LineWidth',1.5);
ylim([0,D_max]);
xlim([U_min-0.01,1]);
for ti=1:length(beta_vec)
    text(SA_U_vec(ti)+0.001,SA_D_vec(ti)+2,['\beta=',num2str(beta_vec(ti))]);
end
for tj=1:length(thres_vec)
    text(TH_U_vec(tj)-0.001,TH_D_vec(tj)-2,['\gamma=',num2str(thres_vec(tj))]);
end
hold off;
legend('blind coding (T=\infty)','ARQ (T=0)','Single Action (T=8)','Threshold Coding (T=8)');
xlabel('Channel Utilization');
ylabel('Expected End-to-End Latency');
grid on;

%save 'T6p3.mat';
% save 'T5Lambda7p2.mat'
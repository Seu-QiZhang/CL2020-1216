%This file is created by XU XIaoli on 23/03/2020
%It compares the latency performance of various coding schemes 
% ARQ-ana
%ARQ-simu
% threshold based coding 
%POMDP based majority vote policy

clc;
clear;
close all;

p_vec=0:0.05:0.45;
N=10000;
lambda=0.5;
T=10;

ARQ_ana=(1-lambda)./(1-p_vec-lambda);
Blind_ana=lambda*p_vec./(1-lambda-p_vec).^2+(1-lambda)./(1-lambda-p_vec);

iter=10;
Thre_simu=ones(iter,length(p_vec));
Thre_modified_simu=ones(iter,length(p_vec));
SA_simu=ones(iter,length(p_vec));
ARQ_delay=ones(iter,length(p_vec));
Blind_simu=ones(iter,length(p_vec));


for i=2:length(p_vec)
    p=p_vec(i);
    for j=1:iter
       [ARQ_delay(j,i),~,~]=getARQDelay(lambda,p,N,T)  
       [ SA_simu(j,i),~]=getSingleAction(lambda,p,N,T,0)
       [Thre_simu(j,i),~]=getThresholdCoding(lambda,p,N,T,1)
       [Thre_modified_simu(j,i),~]=getThresholdCoding_modified(lambda,p,N,T,1)
       [Blind_simu(j,i),~]=getBlindCoding(lambda,p,N)
    end
end
ARQ_delay_mean=sum(ARQ_delay,1)/iter;
Blind_simu_mean=sum(Blind_simu,1)/iter;
Thre_simu_mean=sum(Thre_simu,1)/iter;
Thre_modified_mean=sum(Thre_modified_simu,1)/iter;
SA_simu_mean=sum(SA_simu,1)/iter;


figure;
plot(p_vec,ARQ_ana,'k--','LineWidth',1);
hold on;
plot(p_vec,ARQ_delay_mean,'cd-','LineWidth',1);
plot(p_vec,Blind_ana,'k-','LineWidth',1);
plot(p_vec,Blind_simu_mean,'ko','MarkerFaceColor','k');
plot(p_vec,Thre_simu_mean,'rs-','LineWidth',1);
plot(p_vec,Thre_modified_mean,'bs-','LineWidth',1);
plot(p_vec,SA_simu_mean,'mv-','LineWidth',1);

hold off;
grid on;
xlabel('$p$');
ylabel('Expected E2E Latency');
legend('ARQ with $T=0$','ARQ with $T=10$','Blind coding (ana)','Blind coding (simu)',...
    'Threshold coding ($\gamma=1$)','Threshold modified ($\gamma=1$)','Single action ($\beta=0$)');
ylim([0,25]);

% filename=['Results_N',num2str(N),'_T',num2str(T),'.mat'];
% save(filename);

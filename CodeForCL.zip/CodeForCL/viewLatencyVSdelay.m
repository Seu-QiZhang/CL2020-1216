
clc;
clear;
close all;

T_vec=0:5:30;
N=1000;
lambda=0.7;
p=0.2;
iter=10;
ARQ_ana=(1-lambda)./(1-p-lambda);
Blind_ana=lambda*p./(1-lambda-p).^2+(1-lambda)./(1-lambda-p);

%Vector to store the simulation results
Thre_simu=zeros(iter,length(T_vec));
Thre_simu_modified=zeros(iter,length(T_vec));
SA_simu=zeros(iter,length(T_vec));
ARQ_delay=zeros(iter,length(T_vec));
    

Queue_std_SA=zeros(1,length(T_vec));
Queue_CI_SA=zeros(2,length(T_vec));
Queue_std_Thre=zeros(1,length(T_vec));
Queue_CI_Thre=zeros(2,length(T_vec));
Queue_std_Thre_Modified=zeros(1,length(T_vec));
Queue_CI_Thre_Modified=zeros(2,length(T_vec));
Queue_std_ARQ=zeros(1,length(T_vec));
Queue_CI_ARQ=zeros(2,length(T_vec));


for i=1:length(T_vec)
    T=T_vec(i)
    for j=1:iter
        [ARQ_delay(j,i),~,~]=getARQDelay(lambda,p,N,T)  
        [ SA_simu(j,i),~]=getSingleAction(lambda,p,N,T,0)
        [Thre_simu(j,i),~]=getThresholdCoding(lambda,p,N,T,1)
       [Thre_simu_modified(j,i),~]=getThresholdCoding_modified(lambda,p,N,T,1)
    end
end

ARQ_delay_mean=sum(ARQ_delay,1)/iter;
SA_simu_mean=sum(SA_simu,1)/iter;
Thre_simu_mean=sum(Thre_simu,1)/iter;
Thre_simu_modified_mean=sum(Thre_simu_modified,1)/iter;

%=====================Plot the variance========================
ARQ_std=zeros(1,length(T_vec));
SA_std=zeros(1,length(T_vec));
Thre_std=zeros(1,length(T_vec));
Thre_modified_std=zeros(1,length(T_vec));

ARQ_CI=zeros(2,length(T_vec));
SA_CI=zeros(2,length(T_vec));
Thre_CI=zeros(2,length(T_vec));
Thre_modified_CI=zeros(2,length(T_vec));

for i=1:length(T_vec)
    ARQ_std(i)=std(ARQ_delay(:,i));
    SA_std(i)=std(SA_simu(:,i));
    Thre_std(i)=std(Thre_simu(:,i));
    Thre_modified_std(i)=std(Thre_simu_modified(:,i));  
    
    ARQ_SEM=ARQ_std(i)/sqrt(iter); %standard error
    ARQ_ts=tinv([0.025 0.095],iter-1);
    ARQ_CI(:,i)=ARQ_std(i)+ARQ_ts*ARQ_SEM;
    
    
    SA_SEM=SA_std(i)/sqrt(iter); %standard error
    SA_ts=tinv([0.025 0.095],iter-1);
    SA_CI(:,i)=SA_std(i)+SA_ts*SA_SEM;
    
    Thre_SEM=Thre_std(i)/sqrt(iter); %standard error
    Thre_ts=tinv([0.025 0.095],iter-1);
    Thre_CI(:,i)=Thre_std(i)+Thre_ts*Thre_SEM;
    
    Thre_modified_SEM=Thre_modified_std(i)/sqrt(iter); %standard error
    Thre_modified_ts=tinv([0.025 0.095],iter-1);
    Thre_modified_CI(:,i)=Thre_modified_std(i)+Thre_modified_ts*Thre_modified_SEM;
end


figure;
errorbar(T_vec,Thre_simu_mean,Thre_CI(1,:),Thre_CI(2,:),'rs-','MarkerFaceColor','r','LineWidth',1);
hold on;
grid on;
errorbar(T_vec,Thre_simu_modified_mean,Thre_modified_CI(1,:),Thre_modified_CI(2,:),'bd-','MarkerFaceColor','b','LineWidth',1);
errorbar(T_vec,SA_simu_mean,SA_CI(1,:),SA_CI(2,:),'m+-','MarkerFaceColor','m','LineWidth',1);
errorbar(T_vec,ARQ_delay_mean,ARQ_CI(1,:),ARQ_CI(2,:),'cd-','MarkerFaceColor','c','LineWidth',1);
plot(T_vec,Blind_ana*ones(1,length(T_vec)),'ko-');
hold off;
% title(['p=',num2str(p),', lambda=',num2str(lambda)]);
xlabel('Feedback delay');
ylabel('End-to-end latency');
legend('Delayed ARQ','Greedy Coding');
ylim([0,40]);

legend('Threshold Coding ($\gamma=1$)','Threshold Modified ($\gamma=1$)','Single-Action($\beta=0$)','ARQ with delayed FB','Blind Coding ($\alpha=1$)');

%  filename=['T3Results_N1',num2str(N),'_T',num2str(T),'.mat'];
%  save(filename);





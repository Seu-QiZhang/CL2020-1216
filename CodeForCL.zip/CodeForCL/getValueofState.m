%The file is created by Xu Xiaoli on 27/04/2020
%It estimate the value of belief
function value=getValueofState(belief,p,lambda,beta)
%this approximation does not use lambda, we may improve the value
%approximation with lambda
%value=-(r+w)*(w-d)/(1-p)-(r+1)*r/(2*(1-p));
r_vec=belief(1,:);
w_vec=belief(2,:);
d_vec=belief(3,:);
prob=belief(4,:);

value_vec1=(w_vec-d_vec)/(1-p)+r_vec/((1-p)*(1-lambda));
%value_vec2=r_vec.*(r_vec+1)/(2*(1-p)*(1-lambda))+(r_vec+w_vec).*(w_vec-d_vec)/(1-p);
%value_vec2=r_vec.*(r_vec+1)/(2*(1-p))+(r_vec+w_vec).*(w_vec-d_vec)/(1-p);
value_vec2=r_vec.*(r_vec+1)/((1-p)*(1-lambda))+(r_vec+w_vec).*(w_vec-d_vec)/((1-p)*(1-lambda));


value_vec=-beta*value_vec1-(1-beta)*value_vec2;
%value_vec2=-(r_vec+w_vec).*(w_vec-d_vec)-(r_vec+1).*r_vec/(2*(1-lambda)); %Better than greedy, but not as good as threshold

%value_vec=-(r_vec+w_vec).*(r_vec+w_vec-d_vec);% Very poor performance, even worse than greedy. 
%  value_vec=-r_vec/(1-lambda)-(w_vec-d_vec+r_vec*p/(1-lambda))/(1-p-lambda);% greedy steps to all zeros
% value_vec=-(w_vec-d_vec)/(1-p)-(r_vec+(w_vec-d_vec)*lambda/(1-p))/(1-lambda-p);
%value_vec=-(r_vec+w_vec).*(w_vec-d_vec)/(1-p-lambda);
%=========
% greedy=lambda*p/(1-p-lambda)^2+(1-lambda)/(1-p-lambda);
% value_vec=-(r_vec+w_vec-d_vec).*(r_vec+w_vec-greedy*lambda)/(1-p);
%==========
value=value_vec*prob';


